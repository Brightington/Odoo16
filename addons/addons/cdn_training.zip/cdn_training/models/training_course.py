from odoo import models, fields, api

class TrainingCourse(models.Model):
    _name = 'training.course'
    _description = 'tabel Training Course'

    name = fields.Char(string='Nama Kursus')
    keterangan = fields.Text(string='Keterangan')
    user_id = fields.Many2one(comodel_name='res.users',string='Penanggung Jawab')

    
    
